import styles from "../styles/Home.module.css";
import Navbar from "./Navbar/Navbar";
import SearchAuto from "../libs/SearchAuto";
import Search from "../libs/Search";

export default function App() {
    return (
        <div className={styles.container}>
            <Navbar />
            <Search />
        </div>
    );
}