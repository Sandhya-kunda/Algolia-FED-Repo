import Link from "next/link"
import styles from "../Navbar/Navbar.module.css";
import CustomSearchBox from "../../libs/CustomSearch/CustomSearchBox";

const Navbar=({options})=>{
return <>
<nav className={styles.navbar}>
  <Link href="">Careers</Link>
  <Link href="">Help</Link>
  <Link href="">Store finder</Link>
</nav>
</>
}

export default Navbar;